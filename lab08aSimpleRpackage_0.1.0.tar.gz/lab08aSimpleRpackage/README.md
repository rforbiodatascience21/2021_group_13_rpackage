# 2021_group_13_rpackage
A repo for our first R package as a team for this course.
We represent 3 white males from europe, but wish to be judged fairly and equally.
We hope you can easily read and understand our package. Especially from the well written documentation.



Also we hope that you can laugh at line 3 and not be offended. Thank you.
